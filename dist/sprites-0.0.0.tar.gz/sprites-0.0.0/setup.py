from setuptools import find_packages, setup

setup(
    name='sprites',
    packages=find_packages(),
    #packages=find_packages(include=['sprites_datagen*', 'sprites_env*', 'utils*']),
)
